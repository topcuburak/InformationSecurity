To run the given question3.py file

$python3 Question3.py

- This will generate the desired plain text for given key (A) and desired key for given plaintext (B).
- We can take those key values and plaintexts from the user. To do so, user uncomment the commented lines
  at the end of the given python code.
